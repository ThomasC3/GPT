import useInterval from 'useInterval';

export { useInterval };
export default {
  useInterval
};
