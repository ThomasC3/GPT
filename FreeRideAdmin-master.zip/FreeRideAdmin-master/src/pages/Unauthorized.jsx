import React, { Component } from 'react';


class Unauthorized extends Component {
  render() {
    return (
      <div>Unauthorized</div>
    );
  }
}

export default Unauthorized;
