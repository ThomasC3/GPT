* [Setup](https://github.com/thefreerideinc/FreeRideBackend/wiki/Setup#admin)
* [Deployment](https://github.com/thefreerideinc/FreeRideBackend/wiki/Deployment#admin)

See [the backend wiki](https://github.com/thefreerideinc/FreeRideBackend/wiki) for more information.
